setwd("C:/Users/it24102226/Desktop/IT24102226")

branch_data<-read.table("Exercise.txt", header=TRUE, sep = ",")

fix(branch_data)
attach(branch_data)
str(branch_data)
boxplot(branch_data$Sales_X1, main="boxplot for sales", outline=TRUE, outpch=8, horizontal=TRUE)

summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

get.outliers<-function(x){
  q1 <-quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  IQR <- IQR(x)
  lb <- q1 - 1.5 * IQR
  ub <- q3 + 1.5 * IQR
  outliers <- x[x < lb | x > ub]
  return(outliers)
}
get.outliers(branch_data$Years_X3)